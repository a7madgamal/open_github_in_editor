## v0.0.1

- first version 🎉

## v0.0.2

- open options page on first run
- cleanup of the options page
