# open_github_in_editor
A chrome extension for opening a github diff line in your editor 💻 (currently vscode)
