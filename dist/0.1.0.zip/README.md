# Open Github in editor

## v0.1.0

A chrome extension for opening a github diff line in your editor 💻

![](record.gif)

https://chrome.google.com/webstore/detail/open-github-in-editor/epklehdbjbicoeeebecaeeeceflgpmga/

- Supports vscode, vscode-isiders and textmate.
- More editors soon, maybe also support for gitlab who knows!!

# Changelog

## v0.0.1

- first version 🎉

## v0.0.2

- open options page on first run
- cleanup of the options page

## v0.0.3

- add gif and some icons

## v0.1.0

- added support for textmate
- moved the changelog to readme
